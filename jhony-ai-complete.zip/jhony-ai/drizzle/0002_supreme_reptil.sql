CREATE TABLE `userPreferences` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`theme` enum('light','dark') NOT NULL DEFAULT 'dark',
	`defaultModel` varchar(64) NOT NULL DEFAULT 'gpt-4',
	`defaultImageModel` enum('dalle3','midjourney') NOT NULL DEFAULT 'dalle3',
	`defaultImageStyle` enum('realistic','artistic','abstract','cartoon','anime') NOT NULL DEFAULT 'realistic',
	`defaultImageResolution` enum('1024x1024','1792x1024','1024x1792') NOT NULL DEFAULT '1024x1024',
	`enableNotifications` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `userPreferences_id` PRIMARY KEY(`id`),
	CONSTRAINT `userPreferences_userId_unique` UNIQUE(`userId`)
);
