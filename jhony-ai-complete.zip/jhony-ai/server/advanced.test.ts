import { describe, expect, it } from "vitest";
import {
  calculateSimilarity,
  findSimilarCachedResponse,
  summarizeText,
  detectUserIntent,
  analyzeSentiment,
  globalCache,
  CacheManager,
} from "./cache";
import {
  selectModelByCapability,
  selectFastestModel,
  selectCheapestModel,
  estimateCost,
  validateModelSettings,
  recommendModelForTask,
  DEFAULT_MODEL_SETTINGS,
} from "./models";

describe("Cache Manager", () => {
  it("should store and retrieve values", () => {
    const cache = new CacheManager();
    cache.set("test-key", "test-value");

    expect(cache.get("test-key")).toBe("test-value");
  });

  it("should return null for expired entries", async () => {
    const cache = new CacheManager();
    cache.set("test-key", "test-value", 100); // 100ms TTL

    await new Promise((resolve) => setTimeout(resolve, 150));

    expect(cache.get("test-key")).toBeNull();
  });

  it("should check if key exists", () => {
    const cache = new CacheManager();
    cache.set("test-key", "test-value");

    expect(cache.has("test-key")).toBe(true);
    expect(cache.has("non-existent")).toBe(false);
  });

  it("should delete keys", () => {
    const cache = new CacheManager();
    cache.set("test-key", "test-value");
    cache.delete("test-key");

    expect(cache.has("test-key")).toBe(false);
  });

  it("should clear all entries", () => {
    const cache = new CacheManager();
    cache.set("key1", "value1");
    cache.set("key2", "value2");
    cache.clear();

    expect(cache.has("key1")).toBe(false);
    expect(cache.has("key2")).toBe(false);
  });
});

describe("Similarity & Semantic Search", () => {
  it("should calculate similarity between strings", () => {
    const similarity1 = calculateSimilarity("hello", "hello");
    expect(similarity1).toBe(1);

    const similarity2 = calculateSimilarity("hello", "hallo");
    expect(similarity2).toBeGreaterThan(0.5);

    const similarity3 = calculateSimilarity("hello", "world");
    expect(similarity3).toBeLessThan(0.5);
  });

  it("should find similar cached responses", () => {
    globalCache.set("Como fazer café?", "Você precisa de água quente...");
    globalCache.set("Como fazer chá?", "Você precisa de água quente...");

    const result = findSimilarCachedResponse("Como fazer café?", 0.8);
    expect(result).not.toBeNull();
    expect(result?.similarity).toBeGreaterThan(0.8);
  });
});

describe("Text Processing", () => {
  it("should summarize long text", () => {
    const longText =
      "Este é um texto muito longo que precisa ser resumido. " +
      "Ele contém muitas informações que não são essenciais. " +
      "O resumo deve manter apenas os pontos principais.";

    const summary = summarizeText(longText, 50);
    expect(summary.length).toBeLessThanOrEqual(53); // 50 + "..."
    expect(summary.endsWith("...")).toBe(true);
  });

  it("should not summarize short text", () => {
    const shortText = "Texto curto";
    const summary = summarizeText(shortText, 50);
    expect(summary).toBe(shortText);
  });
});

describe("Intent Detection", () => {
  it("should detect questions", () => {
    expect(detectUserIntent("O que é IA?")).toBe("question");
    expect(detectUserIntent("Como funciona?")).toBe("question");
    expect(detectUserIntent("Por que isso?")).toBe("question");
  });

  it("should detect commands", () => {
    expect(detectUserIntent("/help")).toBe("command");
    expect(detectUserIntent("!execute")).toBe("command");
  });

  it("should detect greetings", () => {
    expect(detectUserIntent("Oi!")).toBe("greeting");
    expect(detectUserIntent("Olá")).toBe("greeting");
  });

  it("should detect statements", () => {
    expect(detectUserIntent("Isso é interessante.")).toBe("statement");
    expect(detectUserIntent("Tenho uma ideia.")).toBe("statement");
  });
});

describe("Sentiment Analysis", () => {
  it("should detect positive sentiment", () => {
    expect(analyzeSentiment("Adorei! Excelente!")).toBe("positive");
    expect(analyzeSentiment("Muito bom")).toBe("positive");
  });

  it("should detect negative sentiment", () => {
    expect(analyzeSentiment("Horrível! Péssimo!")).toBe("negative");
    expect(analyzeSentiment("Muito ruim")).toBe("negative");
  });

  it("should detect neutral sentiment", () => {
    expect(analyzeSentiment("Isso é um fato.")).toBe("neutral");
    expect(analyzeSentiment("Informação normal.")).toBe("neutral");
  });
});

describe("Model Selection", () => {
  it("should select model by capability", () => {
    const model = selectModelByCapability("code");
    expect(model).not.toBeNull();
    expect(model?.capabilities).toContain("code");
  });

  it("should select fastest model", () => {
    const model = selectFastestModel();
    expect(model).not.toBeNull();
    expect(model?.avgResponseTime).toBeLessThan(5000);
  });

  it("should select cheapest model", () => {
    const model = selectCheapestModel();
    expect(model).not.toBeNull();
    expect(model?.costPer1kTokens).toBeGreaterThanOrEqual(0);
  });

  it("should estimate cost", () => {
    const cost = estimateCost("gpt-3.5-turbo", 1000, 1000);
    expect(cost).toBeGreaterThan(0);
    expect(cost).toBeLessThan(0.01); // Should be cheap
  });

  it("should validate model settings", () => {
    const validSettings = DEFAULT_MODEL_SETTINGS;
    const errors = validateModelSettings(validSettings);
    expect(errors).toHaveLength(0);

    const invalidSettings = {
      ...DEFAULT_MODEL_SETTINGS,
      temperature: 5, // Invalid
    };
    const invalidErrors = validateModelSettings(invalidSettings);
    expect(invalidErrors.length).toBeGreaterThan(0);
  });

  it("should recommend model for task", () => {
    const analysisModel = recommendModelForTask("analysis");
    expect(analysisModel).not.toBeNull();
    expect(analysisModel?.capabilities).toContain("analysis");

    const codingModel = recommendModelForTask("coding");
    expect(codingModel).not.toBeNull();
    expect(codingModel?.capabilities).toContain("code");

    const fastModel = recommendModelForTask("fast");
    expect(fastModel).not.toBeNull();

    const cheapModel = recommendModelForTask("cheap");
    expect(cheapModel).not.toBeNull();
  });
});
