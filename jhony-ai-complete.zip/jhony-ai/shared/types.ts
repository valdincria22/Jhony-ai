/**
 * Unified type exports
 * Import shared types from this single entry point.
 */

export type * from "../drizzle/schema";
export * from "./_core/errors";

export interface Message {
  id?: number;
  conversationId?: number;
  role: "user" | "assistant";
  content: string;
  attachments?: Array<{ type: string; url: string; name: string; mimeType?: string }> | null;
  createdAt: Date;
}

export interface Conversation {
  id: number;
  userId: number;
  title: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface FileUpload {
  id: number;
  userId: number;
  conversationId?: number;
  fileName: string;
  fileKey: string;
  fileUrl: string;
  mimeType: string;
  fileSize: number;
  createdAt: Date;
}
