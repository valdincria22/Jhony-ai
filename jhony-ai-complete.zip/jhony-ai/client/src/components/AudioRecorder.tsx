import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Mic, Square, Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";

interface AudioRecorderProps {
  onTranscription?: (text: string) => void;
}

export function AudioRecorder({ onTranscription }: AudioRecorderProps) {
  const [isRecording, setIsRecording] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const transcribeAudioMutation = trpc.chat.transcribeAudio.useMutation();

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, {
          type: "audio/webm",
        });
        await processAudio(audioBlob);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error("Error accessing microphone:", error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processAudio = async (audioBlob: Blob) => {
    try {
      // Create FormData for file upload
      const formData = new FormData();
      formData.append("file", audioBlob, "recording.webm");

      // Upload to storage endpoint
      const uploadResponse = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (!uploadResponse.ok) {
        throw new Error("Failed to upload audio");
      }

      const uploadData = await uploadResponse.json();
      const audioUrl = uploadData.url;

      // Transcribe using tRPC
      const result = await transcribeAudioMutation.mutateAsync({
        audioUrl,
      });

      if (result.text) {
        onTranscription?.(result.text);
      }
    } catch (error) {
      console.error("Error processing audio:", error);
    }
  };

  return (
    <div className="flex gap-2">
      {!isRecording ? (
        <Button
          size="sm"
          variant="outline"
          onClick={startRecording}
          className="gap-2"
        >
          <Mic className="w-4 h-4" />
          Gravar
        </Button>
      ) : (
        <Button
          size="sm"
          variant="destructive"
          onClick={stopRecording}
          className="gap-2"
        >
          <Square className="w-4 h-4" />
          Parar
        </Button>
      )}
      {transcribeAudioMutation.isPending && (
        <Loader2 className="w-4 h-4 animate-spin" />
      )}
    </div>
  );
}
