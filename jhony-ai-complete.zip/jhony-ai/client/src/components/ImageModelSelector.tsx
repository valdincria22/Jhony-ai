import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Sparkles } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface ImageModelSelectorProps {
  onImageGenerated: (url: string, model: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

type ImageModel = "dalle3" | "midjourney";
type ImageStyle = "realistic" | "artistic" | "abstract" | "cartoon" | "anime";

export function ImageModelSelector({
  onImageGenerated,
  isOpen,
  onClose,
}: ImageModelSelectorProps) {
  const [prompt, setPrompt] = useState("");
  const [model, setModel] = useState<ImageModel>("dalle3");
  const [style, setStyle] = useState<ImageStyle>("realistic");
  const [isLoading, setIsLoading] = useState(false);

  const generateImageMutation = trpc.chat.generateImage.useMutation();

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error("Por favor, descreva a imagem que deseja gerar");
      return;
    }

    setIsLoading(true);
    try {
      console.log("[DEBUG] Gerando imagem com modelo:", model);
      const result = await generateImageMutation.mutateAsync({
        prompt,
        model,
        style,
      });

      console.log("[DEBUG] Imagem gerada com sucesso:", result);
      onImageGenerated(result.imageUrl || "", model);
      toast.success(`Imagem gerada com ${model === "dalle3" ? "DALL-E 3" : "Midjourney"}!`);
      setPrompt("");
      onClose();
    } catch (error) {
      console.error("[ERROR] Erro ao gerar imagem:", error);
      const errorMsg = error instanceof Error ? error.message : "Erro ao gerar imagem";
      toast.error(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Gerar Imagem
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Descrição da Imagem */}
          <div>
            <label className="text-sm font-medium mb-2 block">Descrição da Imagem</label>
            <Textarea
              placeholder="Descreva a imagem que deseja gerar..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              className="min-h-24"
              disabled={isLoading}
            />
          </div>

          {/* Modelo */}
          <div>
            <label className="text-sm font-medium mb-2 block">Modelo</label>
            <Select value={model} onValueChange={(value) => setModel(value as ImageModel)} disabled={isLoading}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dalle3">DALL-E 3 (Realista)</SelectItem>
                <SelectItem value="midjourney">Midjourney (Artístico)</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              {model === "dalle3"
                ? "Excelente para imagens realistas e detalhadas"
                : "Perfeito para arte e estilos criativos"}
            </p>
          </div>

          {/* Estilo */}
          <div>
            <label className="text-sm font-medium mb-2 block">Estilo</label>
            <Select value={style} onValueChange={(value) => setStyle(value as ImageStyle)} disabled={isLoading}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="realistic">Realista</SelectItem>
                <SelectItem value="artistic">Artístico</SelectItem>
                <SelectItem value="abstract">Abstrato</SelectItem>
                <SelectItem value="cartoon">Cartoon</SelectItem>
                <SelectItem value="anime">Anime</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Botões */}
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              Cancelar
            </Button>
            <Button onClick={handleGenerate} disabled={isLoading || !prompt.trim()}>
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Gerando...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 mr-2" />
                  Gerar Imagem
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
