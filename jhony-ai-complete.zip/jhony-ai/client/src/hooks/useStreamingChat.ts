import { useState, useCallback, useRef } from "react";

interface StreamingMessage {
  chunk: string;
  fullResponse: string;
}

export function useStreamingChat() {
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  const cancelStream = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsStreaming(false);
    }
  }, []);

  const sendMessageWithStream = useCallback(
    async (
      conversationId: number,
      content: string,
      userId: number,
      onChunk: (chunk: StreamingMessage) => void,
      onComplete: (fullResponse: string) => void
    ) => {
      setIsStreaming(true);
      setError(null);

      // Criar novo AbortController para este request
      abortControllerRef.current = new AbortController();

      try {
        const response = await fetch("/api/chat/stream", {
          signal: abortControllerRef.current.signal,
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            conversationId,
            content,
            userId,
          }),
        });

        if (!response.ok) {
          throw new Error("Failed to send message");
        }

        if (!response.body) {
          throw new Error("No response body");
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();

          if (done) break;

          buffer += decoder.decode(value, { stream: true });

          // Parse SSE messages
          const lines = buffer.split("\n");
          buffer = lines[lines.length - 1];

          for (let i = 0; i < lines.length - 1; i++) {
            const line = lines[i];
            if (line.startsWith("data: ")) {
              try {
                const data = JSON.parse(line.slice(6));

                if (data.done) {
                  onComplete(data.fullResponse);
                } else if (data.error) {
                  setError(data.error);
                } else {
                  onChunk(data);
                }
              } catch (e) {
                console.error("Error parsing SSE message:", e);
              }
            }
          }
        }
      } catch (err) {
        const errorMessage =
          err instanceof Error ? err.message : "Unknown error";
        setError(errorMessage);
        console.error("Streaming error:", err);
      } finally {
        setIsStreaming(false);
      }
    },
    []
  );

  return {
    isStreaming,
    error,
    sendMessageWithStream,
    cancelStream,
  };
}
