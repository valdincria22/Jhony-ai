import React, { useState, useCallback } from "react";
import { ChevronUp, ChevronDown, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface PaginationState {
  currentPage: number;
  totalPages: number;
  pageSize: number;
  isLoading: boolean;
  hasMore: boolean;
}

export interface MessagePaginationProps {
  onLoadMore: (page: number) => Promise<void>;
  state: PaginationState;
  position?: "top" | "bottom";
}

/**
 * Componente de paginação para carregar mais mensagens
 */
export function MessagePagination({
  onLoadMore,
  state,
  position = "top",
}: MessagePaginationProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleLoadMore = useCallback(async () => {
    setIsLoading(true);
    try {
      await onLoadMore(state.currentPage + 1);
    } finally {
      setIsLoading(false);
    }
  }, [onLoadMore, state.currentPage]);

  if (!state.hasMore) {
    return null;
  }

  const Icon = position === "top" ? ChevronUp : ChevronDown;

  return (
    <div className="flex justify-center py-4">
      <Button
        variant="outline"
        size="sm"
        onClick={handleLoadMore}
        disabled={isLoading}
        className="gap-2"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin" />
            Carregando...
          </>
        ) : (
          <>
            <Icon className="w-4 h-4" />
            {position === "top"
              ? "Carregar mensagens anteriores"
              : "Carregar mais mensagens"}
          </>
        )}
      </Button>
    </div>
  );
}

/**
 * Hook para gerenciar paginação de mensagens
 */
export function usePaginatedMessages(pageSize: number = 20) {
  const [messages, setMessages] = useState<any[]>([]);
  const [pagination, setPagination] = useState<PaginationState>({
    currentPage: 0,
    totalPages: 1,
    pageSize,
    isLoading: false,
    hasMore: true,
  });

  const loadPage = useCallback(
    async (page: number, fetchFn: (page: number) => Promise<any[]>) => {
      setPagination((prev) => ({ ...prev, isLoading: true }));
      try {
        const newMessages = await fetchFn(page);
        setMessages((prev) =>
          page === 0 ? newMessages : [...newMessages, ...prev]
        );
        setPagination((prev) => ({
          ...prev,
          currentPage: page,
          hasMore: newMessages.length === pageSize,
        }));
      } finally {
        setPagination((prev) => ({ ...prev, isLoading: false }));
      }
    },
    [pageSize]
  );

  const addMessage = useCallback((message: any) => {
    setMessages((prev) => [...prev, message]);
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setPagination({
      currentPage: 0,
      totalPages: 1,
      pageSize,
      isLoading: false,
      hasMore: true,
    });
  }, [pageSize]);

  return {
    messages,
    pagination,
    loadPage,
    addMessage,
    clearMessages,
  };
}
