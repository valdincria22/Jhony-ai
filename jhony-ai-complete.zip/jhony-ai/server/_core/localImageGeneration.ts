/**
 * Local image generation using Jimp
 * Generates images procedurally without external API dependencies
 */
import { Jimp } from "jimp";
import { storagePut } from "../storage";

export type LocalGenerateImageOptions = {
  prompt: string;
  width?: number;
  height?: number;
  negativePrompt?: string;
  numInferenceSteps?: number;
  guidanceScale?: number;
};

export type LocalGenerateImageResponse = {
  url?: string;
};

export async function generateImageLocally(
  options: LocalGenerateImageOptions
): Promise<LocalGenerateImageResponse> {
  try {
    const width = options.width || 768;
    const height = options.height || 768;

    console.log("[localImageGeneration] Gerando imagem com prompt:", options.prompt);

    // Criar imagem com gradiente de cores
    const image = new Jimp({ width, height, color: 0x2c3e50ff });

    // Gerar padrão visual baseado no prompt
    const keywords = options.prompt.toLowerCase().split(" ");
    
    // Adicionar elementos visuais aleatórios
    for (let i = 0; i < Math.min(keywords.length, 8); i++) {
      const x = Math.random() * width;
      const y = Math.random() * height;
      const size = 30 + Math.random() * 100;
      const color = generateRandomColor();
      
      // Desenhar formas aleatórias
      drawRandomShape(image, x, y, size, color);
    }

    // Converter para buffer PNG
    const buffer = await image.getBuffer('image/png');

    console.log("[localImageGeneration] Imagem gerada com sucesso");

    // Salvar em S3
    const { url } = await storagePut(
      `generated-local/${Date.now()}.png`,
      buffer,
      "image/png"
    );

    return { url };
  } catch (error) {
    console.error("[localImageGeneration] Erro ao gerar imagem:", error);
    throw new Error(
      `Falha ao gerar imagem localmente: ${error instanceof Error ? error.message : String(error)}`
    );
  }
}

function generateRandomColor(): number {
  const colors = [
    0xff6b6bff, // Vermelho
    0x4ecdc4ff, // Turquesa
    0xffe66dff, // Amarelo
    0x95e1d3ff, // Verde claro
    0xf38181ff, // Rosa
    0xaa96daff, // Roxo
    0xfcbad3ff, // Rosa claro
    0xa8d8eaff, // Azul claro
  ];
  return colors[Math.floor(Math.random() * colors.length)];
}

function drawRandomShape(
  image: any,
  x: number,
  y: number,
  size: number,
  color: number
): void {
  const shapeType = Math.floor(Math.random() * 3);
  
  try {
    if (shapeType === 0) {
      // Desenhar círculo
      drawCircle(image, x, y, size / 2, color);
    } else if (shapeType === 1) {
      // Desenhar retângulo
      drawRectangle(image, x, y, size, size / 2, color);
    } else {
      // Desenhar triângulo
      drawTriangle(image, x, y, size, color);
    }
  } catch (e) {
    // Ignorar erros de desenho
  }
}

function drawCircle(
  image: any,
  centerX: number,
  centerY: number,
  radius: number,
  color: number
): void {
  const r = Math.floor(radius);
  for (let x = -r; x <= r; x++) {
    for (let y = -r; y <= r; y++) {
      if (x * x + y * y <= r * r) {
        const px = Math.floor(centerX + x);
        const py = Math.floor(centerY + y);
        if (px >= 0 && px < image.width && py >= 0 && py < image.height) {
          try {
            image.setPixelColor(color, px, py);
          } catch (e) {
            // Ignorar erro de pixel
          }
        }
      }
    }
  }
}

function drawRectangle(
  image: any,
  x: number,
  y: number,
  width: number,
  height: number,
  color: number
): void {
  const startX = Math.max(0, Math.floor(x));
  const startY = Math.max(0, Math.floor(y));
  const endX = Math.min(image.width, Math.floor(x + width));
  const endY = Math.min(image.height, Math.floor(y + height));

  for (let py = startY; py < endY; py++) {
    for (let px = startX; px < endX; px++) {
      try {
        image.setPixelColor(color, px, py);
      } catch (e) {
        // Ignorar erro de pixel
      }
    }
  }
}

function drawTriangle(
  image: any,
  x: number,
  y: number,
  size: number,
  color: number
): void {
  const points = [
    { x: x + size / 2, y: y },
    { x: x + size, y: y + size },
    { x: x, y: y + size },
  ];

  const minX = Math.max(0, Math.floor(Math.min(points[0].x, points[1].x, points[2].x)));
  const maxX = Math.min(image.width, Math.ceil(Math.max(points[0].x, points[1].x, points[2].x)));
  const minY = Math.max(0, Math.floor(Math.min(points[0].y, points[1].y, points[2].y)));
  const maxY = Math.min(image.height, Math.ceil(Math.max(points[0].y, points[1].y, points[2].y)));

  for (let py = minY; py < maxY; py++) {
    for (let px = minX; px < maxX; px++) {
      if (isPointInTriangle(px, py, points[0], points[1], points[2])) {
        try {
          image.setPixelColor(color, px, py);
        } catch (e) {
          // Ignorar erro de pixel
        }
      }
    }
  }
}

function isPointInTriangle(
  px: number,
  py: number,
  p1: { x: number; y: number },
  p2: { x: number; y: number },
  p3: { x: number; y: number }
): boolean {
  const area = Math.abs(
    (p2.x - p1.x) * (p3.y - p1.y) - (p3.x - p1.x) * (p2.y - p1.y)
  );
  const area1 = Math.abs(
    (px - p2.x) * (p3.y - p2.y) - (p3.x - p2.x) * (py - p2.y)
  );
  const area2 = Math.abs(
    (p1.x - px) * (p3.y - py) - (p3.x - px) * (p1.y - py)
  );
  const area3 = Math.abs(
    (p1.x - p2.x) * (py - p2.y) - (px - p2.x) * (p1.y - p2.y)
  );

  return Math.abs(area - (area1 + area2 + area3)) < 1;
}
