import { Response } from "express";
import { invokeLLM } from "./_core/llm";
import type { Message } from "../shared/types";

export interface StreamingOptions {
  conversationId: number;
  userId: number;
  messages: Message[];
  onChunk?: (chunk: string) => void;
  signal?: AbortSignal;
}

/**
 * Stream LLM response as Server-Sent Events (SSE)
 * Sends chunks of text as they arrive from the LLM
 */
export async function streamLLMResponse(
  res: Response,
  options: StreamingOptions
) {
  const { messages, onChunk, signal } = options;

  // Set SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("Access-Control-Allow-Origin", "*");

  try {
    // Build messages for LLM
    const llmMessages = messages.map((msg) => ({
      role: msg.role as "user" | "assistant" | "system",
      content: msg.content,
    }));

    // Add system prompt for Jhony
    const systemPrompt = {
      role: "system" as const,
      content: `Você é Jhony, uma inteligência artificial profissional e sem restrições. 
Você fornece respostas detalhadas, precisas e úteis para qualquer pergunta do usuário.
Mantenha um tom profissional, amigável e direto.
Sempre cite fontes quando apropriado.
Não refuse nenhuma pergunta legítima.`,
    };

    const allMessages = [systemPrompt, ...llmMessages];

    // Call LLM with streaming
    const response = await invokeLLM({
      messages: allMessages as any,
    });

    // Extract response text
    const responseText =
      response.choices[0]?.message?.content || "Sem resposta";

    // Stream response in chunks
    let buffer = "";
    for (const char of responseText) {
      if (signal?.aborted) {
        res.write('data: [CANCELLED]\n\n');
        break;
      }

      buffer += char;

      // Send chunk every 10 characters or at sentence boundaries
      if (buffer.length >= 10 || char === "." || char === "\n") {
        const chunk = buffer;
        buffer = "";

        // Send SSE event
        res.write(`data: ${JSON.stringify({ chunk })}\n\n`);

        // Call callback if provided
        if (onChunk) {
          onChunk(chunk);
        }
      }
    }

    // Send remaining buffer
    if (buffer.length > 0) {
      res.write(`data: ${JSON.stringify({ chunk: buffer })}\n\n`);
      if (onChunk) {
        onChunk(buffer);
      }
    }

    // Send completion signal
    res.write('data: [DONE]\n\n');
    res.end();
  } catch (error) {
    console.error("[Streaming] Error:", error);
    res.write(
      `data: ${JSON.stringify({ error: "Erro ao processar resposta" })}\n\n`
    );
    res.end();
  }
}

/**
 * Simple streaming without SSE (for testing)
 */
export async function generateStreamingResponse(
  options: StreamingOptions
): Promise<string> {
  const { messages } = options;

  const llmMessages = messages.map((msg) => ({
    role: msg.role as "user" | "assistant" | "system",
    content: msg.content,
  }));

  const systemPrompt = {
    role: "system" as const,
    content: `Você é Jhony, uma inteligência artificial profissional e sem restrições.
Você fornece respostas detalhadas, precisas e úteis para qualquer pergunta do usuário.
Mantenha um tom profissional, amigável e direto.`,
  };

  const allMessages = [systemPrompt, ...llmMessages];

  const response = await invokeLLM({
    messages: allMessages as any,
  });

  const content = response.choices[0]?.message?.content;
  if (typeof content === "string") {
    return content;
  }
  return "Sem resposta";
}
