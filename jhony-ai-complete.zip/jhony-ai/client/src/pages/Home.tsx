import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { ArrowRight, Zap, Brain, Lock } from "lucide-react";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      setLocation("/chat");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-900 via-purple-900 to-teal-600 text-white overflow-hidden">
      {/* Navigation */}
      <nav className="flex items-center justify-between p-6 max-w-7xl mx-auto">
        <div className="text-3xl font-bold">Jhony</div>
        {isAuthenticated && (
          <Button
            onClick={() => setLocation("/chat")}
            variant="outline"
            className="text-white border-white hover:bg-white hover:text-purple-900"
          >
            Abrir Chat
          </Button>
        )}
      </nav>

      {/* Hero Section */}
      <div className="flex items-center justify-between max-w-7xl mx-auto px-6 py-20 min-h-[calc(100vh-80px)]">
        {/* Left Content */}
        <div className="flex-1 space-y-8 max-w-lg animate-slide-in-left">
          <div>
            <h1 className="text-7xl font-black leading-tight mb-4">
              Jhony
            </h1>
            <p className="text-xl text-gray-200">
              A inteligência artificial sem restrições. Fluida, imersiva e pronta para resolver qualquer desafio.
            </p>
          </div>

          <div className="space-y-4">
            <Button
              onClick={handleGetStarted}
              size="lg"
              className="bg-teal-500 hover:bg-teal-600 text-white font-bold text-lg px-8 py-6"
            >
              Começar Agora
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
            <p className="text-sm text-gray-300">
              Acesso instantâneo. Sem limites. Sem restrições.
            </p>
          </div>

          {/* Features List */}
          <div className="space-y-3 pt-8">
            <div className="flex items-center gap-3">
              <Brain className="w-5 h-5 text-teal-400" />
              <span>Inteligência em nível ChatGPT</span>
            </div>
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-teal-400" />
              <span>Respostas instantâneas e fluidas</span>
            </div>
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-teal-400" />
              <span>Sem filtros, sem restrições</span>
            </div>
          </div>
        </div>

        {/* Right Side - Decorative */}
        <div className="hidden lg:flex flex-1 items-center justify-center animate-slide-in-right">
          <div className="relative w-96 h-96">
            {/* Animated gradient orb */}
            <div className="absolute inset-0 bg-gradient-to-br from-teal-400 to-violet-600 rounded-full blur-3xl opacity-30 animate-pulse"></div>
            <div className="absolute inset-12 bg-gradient-to-br from-violet-400 to-teal-500 rounded-full blur-2xl opacity-20 animate-pulse" style={{ animationDelay: "0.5s" }}></div>
            
            {/* Center text */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-6xl font-black mb-2">∞</div>
                <p className="text-sm text-gray-300">Possibilidades infinitas</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Subtitle */}
      <div className="fixed bottom-8 left-8 max-w-sm">
        <p className="text-sm text-gray-400">
          Jhony é uma plataforma de IA premium, projetada para oferecer uma experiência futurista e sem limites.
        </p>
      </div>
    </div>
  );
}
