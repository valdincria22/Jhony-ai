import React, { useState } from "react";
import { AlertCircle, RotateCcw, X } from "lucide-react";
import { Button } from "@/components/ui/button";

export interface ErrorState {
  message: string;
  details?: string;
  code?: string;
  retryable?: boolean;
  onRetry?: () => void;
}

export function ErrorAlert({
  error,
  onDismiss,
  onRetry,
}: {
  error: ErrorState;
  onDismiss?: () => void;
  onRetry?: () => void;
}) {
  const [isRetrying, setIsRetrying] = useState(false);

  const handleRetry = async () => {
    setIsRetrying(true);
    try {
      if (onRetry) {
        await onRetry();
      } else if (error.onRetry) {
        await error.onRetry();
      }
    } finally {
      setIsRetrying(false);
    }
  };

  return (
    <div className="bg-destructive/10 border border-destructive text-destructive px-4 py-3 rounded-lg flex items-start gap-3 animate-fade-in">
      <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
      <div className="flex-1">
        <p className="font-semibold">{error.message}</p>
        {error.details && (
          <p className="text-sm opacity-90 mt-1">{error.details}</p>
        )}
        {error.code && (
          <p className="text-xs opacity-75 mt-1">Código: {error.code}</p>
        )}
        <div className="flex gap-2 mt-3">
          {(error.retryable || error.onRetry) && (
            <Button
              size="sm"
              variant="outline"
              onClick={handleRetry}
              disabled={isRetrying}
              className="gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              {isRetrying ? "Tentando..." : "Tentar Novamente"}
            </Button>
          )}
          {onDismiss && (
            <Button
              size="sm"
              variant="ghost"
              onClick={onDismiss}
              className="gap-2"
            >
              <X className="w-4 h-4" />
              Descartar
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

export function ErrorToast({
  error,
  onDismiss,
}: {
  error: ErrorState;
  onDismiss?: () => void;
}) {
  return (
    <div className="fixed bottom-4 right-4 bg-destructive text-destructive-foreground px-4 py-3 rounded-lg shadow-lg flex items-start gap-3 max-w-md animate-slide-in-right z-50">
      <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
      <div className="flex-1">
        <p className="font-semibold text-sm">{error.message}</p>
        {error.details && (
          <p className="text-xs opacity-90 mt-1">{error.details}</p>
        )}
      </div>
      {onDismiss && (
        <button
          onClick={onDismiss}
          className="flex-shrink-0 opacity-70 hover:opacity-100"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

/**
 * Hook para gerenciar estado de erro com retry automático
 */
export function useErrorHandler() {
  const [error, setError] = useState<ErrorState | null>(null);
  const [retryCount, setRetryCount] = useState(0);
  const maxRetries = 3;

  const handleError = (
    err: Error | ErrorState | string,
    retryable = true
  ) => {
    if (typeof err === "string") {
      setError({
        message: err,
        retryable,
      });
    } else if (err instanceof Error) {
      setError({
        message: err.message,
        details: err.stack,
        retryable,
      });
    } else {
      setError({
        ...err,
        retryable,
      });
    }
  };

  const retry = async (fn: () => Promise<void>) => {
    if (retryCount >= maxRetries) {
      setError({
        message: "Número máximo de tentativas atingido",
        details: `Tentou ${maxRetries} vezes sem sucesso`,
        retryable: false,
      });
      return;
    }

    try {
      setRetryCount((prev) => prev + 1);
      await fn();
      setError(null);
      setRetryCount(0);
    } catch (err) {
      handleError(err instanceof Error ? err : new Error(String(err)));
    }
  };

  const clearError = () => {
    setError(null);
    setRetryCount(0);
  };

  return {
    error,
    handleError,
    retry,
    clearError,
    retryCount,
    maxRetries,
  };
}
