import { useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Upload, X, File, Image, Music, Video } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { storagePut } from "@/lib/storage";

interface FileUploadAreaProps {
  conversationId?: number;
  onFileUploaded?: (file: { type: string; url: string; name: string; mimeType: string }) => void;
}

export function FileUploadArea({ conversationId, onFileUploaded }: FileUploadAreaProps) {
  const [files, setFiles] = useState<File[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const uploadFileMutation = trpc.chat.uploadFile.useMutation();

  const getFileIcon = (mimeType: string) => {
    if (mimeType.startsWith("image/")) return <Image className="w-4 h-4" />;
    if (mimeType.startsWith("audio/")) return <Music className="w-4 h-4" />;
    if (mimeType.startsWith("video/")) return <Video className="w-4 h-4" />;
    return <File className="w-4 h-4" />;
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setFiles(Array.from(e.target.files));
    }
  };

  const handleUpload = async () => {
    if (files.length === 0) return;
    setIsUploading(true);

    try {
      for (const file of files) {
        const buffer = await file.arrayBuffer();
        const { key, url } = await storagePut(
          `uploads/${Date.now()}-${file.name}`,
          new Uint8Array(buffer),
          file.type
        );

        if (conversationId) {
          await uploadFileMutation.mutateAsync({
            conversationId,
            fileName: file.name,
            fileKey: key,
            fileUrl: url,
            mimeType: file.type,
            fileSize: file.size,
          });
        }

        onFileUploaded?.({
          type: file.type.startsWith("image/") ? "image" : "file",
          url,
          name: file.name,
          mimeType: file.type,
        });
      }

      setFiles([]);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    } catch (error) {
      console.error("Error uploading file:", error);
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveFile = (index: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="space-y-3">
      <input
        ref={fileInputRef}
        type="file"
        multiple
        onChange={handleFileSelect}
        className="hidden"
        accept="image/*,audio/*,video/*,.pdf,.doc,.docx,.txt"
      />

      {files.length === 0 ? (
        <Button
          type="button"
          variant="outline"
          onClick={() => fileInputRef.current?.click()}
          className="w-full"
          disabled={isUploading}
        >
          <Upload className="w-4 h-4 mr-2" />
          Selecionar Arquivos
        </Button>
      ) : (
        <div className="space-y-2">
          {files.map((file, idx) => (
            <div
              key={idx}
              className="flex items-center justify-between p-2 bg-muted rounded-lg"
            >
              <div className="flex items-center gap-2">
                {getFileIcon(file.type)}
                <span className="text-sm truncate">{file.name}</span>
              </div>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => handleRemoveFile(idx)}
                disabled={isUploading}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}

          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="flex-1"
            >
              Adicionar Mais
            </Button>
            <Button
              type="button"
              onClick={handleUpload}
              disabled={isUploading}
              className="flex-1"
            >
              {isUploading ? "Enviando..." : "Enviar"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
