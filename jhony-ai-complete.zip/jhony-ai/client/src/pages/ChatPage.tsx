import { useEffect, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { useLocation } from "wouter";
import { ChatBox } from "@/components/ChatBox";
import { Sidebar } from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ChatPage() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();
  const [currentConversationId, setCurrentConversationId] = useState<number | null>(null);
  // Sidebar sempre fixado
  const sidebarOpen = true;

  const createConversationMutation = trpc.chat.createConversation.useMutation();

  useEffect(() => {
    if (!loading && !user) {
      setLocation("/");
    }
  }, [user, loading, setLocation]);

  useEffect(() => {
    console.log("[DEBUG] currentConversationId mudou para:", currentConversationId);
  }, [currentConversationId]);

  const handleNewConversation = async () => {
    try {
      console.log("[DEBUG] Iniciando criação de conversa...");
      const result = await createConversationMutation.mutateAsync({});
      console.log("[DEBUG] Conversa criada com sucesso:", result);
      setCurrentConversationId(result.id);
      toast.success("Nova conversa iniciada!");
    } catch (error) {
      console.error("[ERROR] Erro ao criar conversa:", error);
      const errorMsg = error instanceof Error ? error.message : "Erro desconhecido";
      toast.error(`Erro: ${errorMsg}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="text-4xl font-bold mb-2">Jhony</div>
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar - Fixado */}
      <div className="w-64 border-r flex-shrink-0">
        <Sidebar
          currentConversationId={currentConversationId}
          onSelectConversation={setCurrentConversationId}
          onNewConversation={handleNewConversation}
        />
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="border-b p-4 flex items-center justify-between">
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-center">Jhony</h1>
          </div>
        </div>

        {/* Chat Area */}
        {currentConversationId && currentConversationId > 0 ? (
          <ChatBox
            conversationId={currentConversationId}
            onNewConversation={handleNewConversation}
          />
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center">
            <div className="text-center">
              <div className="text-6xl font-bold mb-4">Jhony</div>
              <p className="text-lg text-muted-foreground mb-8">
                Bem-vindo à IA Jhony - Inteligência sem restrições
              </p>
              <Button onClick={handleNewConversation} size="lg">
                Iniciar Conversa
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
