import { Router, Request, Response } from "express";
import { getDb } from "./db";
import { generateStreamingResponse } from "./streaming";
import type { Message } from "../shared/types";

export const webhookRouter = Router();

/**
 * Webhook para receber dúvidas de fontes externas
 * POST /api/webhooks/ask
 * Body: { question: string, source: string, userId?: string }
 */
webhookRouter.post("/ask", async (req: Request, res: Response) => {
  try {
    const { question, source, userId, returnUrl } = req.body;

    if (!question || !source) {
      return res.status(400).json({
        success: false,
        error: "question e source são obrigatórios",
      });
    }

    // Validate source
    const validSources = ["api", "webhook", "whatsapp", "telegram", "discord"];
    if (!validSources.includes(source)) {
      return res.status(400).json({
        success: false,
        error: `source deve ser um de: ${validSources.join(", ")}`,
      });
    }

    // Log webhook request
    console.log(`[Webhook] Recebida dúvida de ${source}: ${question}`);

    // Create message for LLM
    const messages: Message[] = [
      {
        id: 0,
        conversationId: 0,
        role: "user",
        content: question,
        createdAt: new Date(),
        attachments: null,
      },
    ];

    // Generate response
    const response = await generateStreamingResponse({
      conversationId: 0,
      userId: userId ? parseInt(userId) : 0,
      messages,
    });

    // If returnUrl is provided, send response back
    if (returnUrl) {
      try {
        await fetch(returnUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            success: true,
            question,
            response,
            source,
            timestamp: new Date().toISOString(),
          }),
        });
      } catch (error) {
        console.error("[Webhook] Erro ao enviar resposta para returnUrl:", error);
      }
    }

    // Return response
    res.json({
      success: true,
      question,
      response,
      source,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[Webhook] Erro:", error);
    res.status(500).json({
      success: false,
      error: "Erro ao processar webhook",
    });
  }
});

/**
 * Webhook para WhatsApp
 * POST /api/webhooks/whatsapp
 */
webhookRouter.post("/whatsapp", async (req: Request, res: Response) => {
  try {
    const { message, phoneNumber } = req.body;

    if (!message || !phoneNumber) {
      return res.status(400).json({
        success: false,
        error: "message e phoneNumber são obrigatórios",
      });
    }

    console.log(
      `[WhatsApp] Mensagem recebida de ${phoneNumber}: ${message}`
    );

    // Generate response
    const messages: Message[] = [
      {
        id: 0,
        conversationId: 0,
        role: "user",
        content: message,
        createdAt: new Date(),
        attachments: null,
      },
    ];

    const response = await generateStreamingResponse({
      conversationId: 0,
      userId: 0,
      messages,
    });

    res.json({
      success: true,
      message,
      response,
      phoneNumber,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[WhatsApp] Erro:", error);
    res.status(500).json({
      success: false,
      error: "Erro ao processar mensagem WhatsApp",
    });
  }
});

/**
 * Webhook para Telegram
 * POST /api/webhooks/telegram
 */
webhookRouter.post("/telegram", async (req: Request, res: Response) => {
  try {
    const { message, chatId, userId } = req.body;

    if (!message || !chatId) {
      return res.status(400).json({
        success: false,
        error: "message e chatId são obrigatórios",
      });
    }

    console.log(`[Telegram] Mensagem recebida do chat ${chatId}: ${message}`);

    // Generate response
    const messages: Message[] = [
      {
        id: 0,
        conversationId: 0,
        role: "user",
        content: message,
        createdAt: new Date(),
        attachments: null,
      },
    ];

    const response = await generateStreamingResponse({
      conversationId: 0,
      userId: userId ? parseInt(userId) : 0,
      messages,
    });

    res.json({
      success: true,
      message,
      response,
      chatId,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[Telegram] Erro:", error);
    res.status(500).json({
      success: false,
      error: "Erro ao processar mensagem Telegram",
    });
  }
});

/**
 * Webhook para Discord
 * POST /api/webhooks/discord
 */
webhookRouter.post("/discord", async (req: Request, res: Response) => {
  try {
    const { message, channelId, userId } = req.body;

    if (!message || !channelId) {
      return res.status(400).json({
        success: false,
        error: "message e channelId são obrigatórios",
      });
    }

    console.log(
      `[Discord] Mensagem recebida do canal ${channelId}: ${message}`
    );

    // Generate response
    const messages: Message[] = [
      {
        id: 0,
        conversationId: 0,
        role: "user",
        content: message,
        createdAt: new Date(),
        attachments: null,
      },
    ];

    const response = await generateStreamingResponse({
      conversationId: 0,
      userId: userId ? parseInt(userId) : 0,
      messages,
    });

    res.json({
      success: true,
      message,
      response,
      channelId,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[Discord] Erro:", error);
    res.status(500).json({
      success: false,
      error: "Erro ao processar mensagem Discord",
    });
  }
});

/**
 * Webhook para API genérica
 * POST /api/webhooks/generic
 */
webhookRouter.post("/generic", async (req: Request, res: Response) => {
  try {
    const { question, metadata } = req.body;

    if (!question) {
      return res.status(400).json({
        success: false,
        error: "question é obrigatório",
      });
    }

    console.log(`[Generic Webhook] Dúvida recebida: ${question}`);

    // Generate response
    const messages: Message[] = [
      {
        id: 0,
        conversationId: 0,
        role: "user",
        content: question,
        createdAt: new Date(),
        attachments: null,
      },
    ];

    const response = await generateStreamingResponse({
      conversationId: 0,
      userId: 0,
      messages,
    });

    res.json({
      success: true,
      question,
      response,
      metadata,
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    console.error("[Generic Webhook] Erro:", error);
    res.status(500).json({
      success: false,
      error: "Erro ao processar webhook genérico",
    });
  }
});

export default webhookRouter;
