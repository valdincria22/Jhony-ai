-- Add indexes for performance optimization
CREATE INDEX idx_conversations_userId ON conversations(userId);
CREATE INDEX idx_conversations_userId_updatedAt ON conversations(userId, updatedAt DESC);
CREATE INDEX idx_messages_conversationId ON messages(conversationId);
CREATE INDEX idx_messages_conversationId_createdAt ON messages(conversationId, createdAt);
CREATE INDEX idx_fileUploads_userId ON fileUploads(userId);
CREATE INDEX idx_fileUploads_conversationId ON fileUploads(conversationId);
