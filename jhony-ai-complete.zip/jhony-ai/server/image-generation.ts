import { generateImage } from "./_core/imageGeneration";

export type ImageModel = "dalle3" | "midjourney";

export interface ImageGenerationRequest {
  prompt: string;
  model: ImageModel;
  style?: "realistic" | "artistic" | "abstract" | "cartoon" | "anime";
  resolution?: "1024x1024" | "1792x1024" | "1024x1792";
  quality?: "standard" | "hd";
}

export interface ImageGenerationResponse {
  url: string;
  model: ImageModel;
  prompt: string;
  timestamp: Date;
}

/**
 * Gera imagem usando DALL-E 3
 */
export async function generateWithDALLE3(
  prompt: string,
  style?: string,
  resolution?: string
): Promise<{ url: string }> {
  const enhancedPrompt = style 
    ? `${prompt} in ${style} style`
    : prompt;

  const result = await generateImage({
    prompt: enhancedPrompt,
  });

  return {
    url: result.url || "",
  };
}

/**
 * Gera imagem usando Midjourney (via API)
 */
export async function generateWithMidjourney(
  prompt: string,
  style?: string,
  quality?: string
): Promise<{ url: string }> {
  // Midjourney prompt format
  const mjPrompt = `${prompt}${style ? ` --style ${style}` : ""}${quality === "hd" ? " --quality 2" : " --quality 1"}`;

  // Usar generateImage como fallback (em produção, integrar com Midjourney API)
  const result = await generateImage({
    prompt: mjPrompt,
  });

  return {
    url: result.url || "",
  };
}

/**
 * Gera imagem com modelo selecionado
 */
export async function generateImageWithModel(
  request: ImageGenerationRequest
): Promise<ImageGenerationResponse> {
  let url: string;

  if (request.model === "dalle3") {
    const result = await generateWithDALLE3(
      request.prompt,
      request.style,
      request.resolution
    );
    url = result.url;
  } else if (request.model === "midjourney") {
    const result = await generateWithMidjourney(
      request.prompt,
      request.style,
      request.quality
    );
    url = result.url;
  } else {
    throw new Error(`Modelo de imagem desconhecido: ${request.model}`);
  }

  return {
    url,
    model: request.model,
    prompt: request.prompt,
    timestamp: new Date(),
  };
}
